const { Client, GatewayIntentBits } = require('discord.js');
const axios = require('axios');
require('dotenv').config();

const client = new Client({ intents: [GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.Guilds] });
const token = process.env.DISCORD_TOKEN;
const backend = process.env.BACKEND_URL;

let xpMap = {};

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  const userId = message.author.id;
  xpMap[userId] = (xpMap[userId] || 0) + 10;

  try {
    await axios.post(`${backend}/api/update-xp`, {
      id: userId,
      username: message.author.username,
      xp: xpMap[userId]
    });
  } catch (error) {
    console.error('Erro ao enviar XP:', error.message);
  }
});

client.login(token);