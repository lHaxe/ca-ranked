const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const session = require('express-session');
const passport = require('passport');
const DiscordStrategy = require('passport-discord').Strategy;
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;

// MongoDB
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
const UserSchema = new mongoose.Schema({
  discordId: String,
  username: String,
  xp: Number,
});
const User = mongoose.model('User', UserSchema);

// Middleware
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(session({ secret: 'secret', resave: false, saveUninitialized: false }));

// Passport OAuth2 config
passport.use(new DiscordStrategy({
  clientID: process.env.CLIENT_ID,
  clientSecret: process.env.CLIENT_SECRET,
  callbackURL: process.env.CALLBACK_URL,
  scope: ['identify']
}, async (accessToken, refreshToken, profile, cb) => {
  let user = await User.findOne({ discordId: profile.id });
  if (!user) {
    user = await User.create({ discordId: profile.id, username: profile.username, xp: 0 });
  }
  return cb(null, user);
}));

passport.serializeUser((user, done) => done(null, user.id));
passport.deserializeUser((id, done) => User.findById(id).then(user => done(null, user)));

app.use(passport.initialize());
app.use(passport.session());

// Rotas de autenticação
app.get('/auth/discord', passport.authenticate('discord'));
app.get('/auth/discord/callback', passport.authenticate('discord', {
  successRedirect: '/',
  failureRedirect: '/auth/discord'
}));

// API pública
app.get('/api/rank', async (req, res) => {
  const users = await User.find().sort({ xp: -1 }).limit(10);
  res.json(users);
});

app.get('/api/me', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not authenticated' });
  res.json(req.user);
});

app.post('/api/update-xp', async (req, res) => {
  const { id, username, xp } = req.body;
  let user = await User.findOne({ discordId: id });
  if (user) {
    user.xp = xp;
    await user.save();
  } else {
    await User.create({ discordId: id, username, xp });
  }
  res.json({ success: true });
});

app.listen(PORT, () => console.log(`API ouvindo em http://localhost:${PORT}`));